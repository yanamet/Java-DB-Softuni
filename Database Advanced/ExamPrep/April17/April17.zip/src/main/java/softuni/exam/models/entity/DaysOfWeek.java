package softuni.exam.models.entity;

public enum DaysOfWeek {
    FRIDAY, SATURDAY, SUNDAY
}
