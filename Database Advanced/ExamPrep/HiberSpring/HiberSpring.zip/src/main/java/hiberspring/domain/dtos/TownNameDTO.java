package hiberspring.domain.dtos;

public class TownNameDTO {


}
