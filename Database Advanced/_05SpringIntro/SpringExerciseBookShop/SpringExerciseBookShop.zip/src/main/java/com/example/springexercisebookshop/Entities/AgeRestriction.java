package com.example.springexercisebookshop.Entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
