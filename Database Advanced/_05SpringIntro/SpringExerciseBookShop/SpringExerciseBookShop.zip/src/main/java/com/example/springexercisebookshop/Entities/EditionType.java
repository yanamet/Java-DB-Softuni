package com.example.springexercisebookshop.Entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
