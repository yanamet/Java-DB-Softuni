package com.example.springexercisebookshop.Services;

import com.example.springexercisebookshop.Entities.Author;

public interface AuthorService {
    Author getRandomAuthor();
}
