package com.example.springexercisebookshop.Services;

public class BookService {
}
