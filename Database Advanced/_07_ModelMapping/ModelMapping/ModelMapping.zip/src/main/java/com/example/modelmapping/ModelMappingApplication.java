package com.example.modelmapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModelMappingApplication {

    public static void main(String[] args) {

        SpringApplication.run(ModelMappingApplication.class, args);

    }

}
